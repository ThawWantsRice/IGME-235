class Card {
  static cards = [];

  constructor(element, pattern) {
    this.element = element;
    this.pattern = pattern;
    this.flipped = false;

    // Attach click event listener to the card
    this.element.addEventListener("click", () => this.cardClicked());

    // Add the created card to the static cards array
    Card.cards.push(this);
  }

  cardClicked() {
    if (!this.flipped) {
      this.element.classList.add("card-flipped");
      this.flipped = true;
      // Call the function to check for matching patterns or perform other actions
      checkPattern();
    }
  }

  resetCard() {
    this.element.classList.remove("card-flipped", "card-dance");
    this.flipped = false;
  }

  danceAndFlip() {
    this.element.classList.add("card-dance");
    setTimeout(() => {
      this.resetCard();
      danceAndFlipCards();
    }, 50);
  }
}

const numCards = 10;

// 6 pairs of cards in the initial deck
let deck = [
  "cardR01C01", 
  "cardR01C02", 
  "cardR01C03", 
  "cardR01C04", 
  "cardR01C05", 
  "cardR01C06", 
  "cardR01C07", 
  "cardR01C08", 
  "cardR01C09", 
  "cardR01C10", 
];

// Assuming you have defined cardWidth and cardHeight
const cardWidth = 63;
const cardHeight = 67;
const spriteSheetWidth = 624; // Adjust this to the width of your sprite sheet
const spriteSheetHeight = 638; // Adjust this to the height of your sprite sheet

function createCard(pattern) {
  const card = document.createElement("div");
  card.classList.add("card");

  // Front face
  const frontFace = document.createElement("div");
  frontFace.classList.add("face", "front");
  frontFace.style.backgroundPosition = getBackgroundPosition(pattern);
  card.appendChild(frontFace);

  // Back face
  const backFace = document.createElement("div");
  backFace.classList.add("face", "back");
  backFace.style.backgroundPosition = "0 0"; // Adjust as needed
  card.appendChild(backFace);

  document.querySelector("#cards").appendChild(card);
  return card;
}

function getBackgroundPosition(pattern) {
  // Assuming the pattern is in the format "cardR01C01"
  const row = parseInt(pattern.substr(6, 2), 10);
  const col = parseInt(pattern.substr(9, 2), 10);

  // Calculate the background position based on sprite sheet dimensions and card size
  const xPos = (col - 1) * cardWidth;
  const yPos = (row - 1) * cardHeight;

  // Calculate the percentage position within the sprite sheet
  const backgroundX = (xPos / spriteSheetWidth) * 100;
  const backgroundY = (yPos / spriteSheetHeight) * 100;

  return `${backgroundX}% ${backgroundY}%`;
}


function initBoard() {
  // Shuffle the deck
  deck.sort(() => 0.5 - Math.random());

  // Clear any existing cards from the array
  Card.cards.length = 0;

  // Create Card objects for each card element
  for (let i = 0; i < numCards; i++) {
    const pattern = deck[i];
    const cardElement = createCard(pattern);
    const card = new Card(cardElement, pattern);
  }
}

function checkPattern() {
  // Logic to check patterns and perform actions
  // Modify this function based on your game's requirements
}

function danceAndFlipCards() {
  Card.cards.forEach((card) => {
    if (card.flipped) {
      card.danceAndFlip();
    }
  });
}

window.onload = () => {
  initBoard();
};
