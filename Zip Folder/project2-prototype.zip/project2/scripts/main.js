window.onload = (e) => {
    document.querySelector("#breedDropdown").addEventListener("change", searchButtonClicked);
    document.querySelector("#searchButton").addEventListener("click", searchRandomImage);
    document.querySelector("#clearLocalStorage").addEventListener("click", clearLocalStorage);
    getDogBreeds();
};

function searchButtonClicked() {
    const selectedBreed = document.querySelector("#breedDropdown").value;

    if (!selectedBreed) {
        alert("Please select a dog breed");
        return;
    }

    // Highlight the selected breed
    highlightSelectedBreed(selectedBreed);

    // Display sub-breeds if available
    displaySubBreeds(selectedBreed);
}

function highlightSelectedBreed(selectedBreed) {
    const breedDropdown = document.querySelector("#breedDropdown");
    
    for (const option of breedDropdown.options) {
        option.style.fontWeight = "normal";
    }

    const selectedOption = breedDropdown.querySelector(`[value="${selectedBreed}"]`);
    if (selectedOption) {
        selectedOption.style.fontWeight = "bold";
    }
}

function displaySubBreeds(selectedBreed) {
    const subBreedsUrl = `https://dog.ceo/api/breed/${selectedBreed}/list`;

    let xhrSubBreeds = new XMLHttpRequest();
    xhrSubBreeds.onreadystatechange = function () {
        if (xhrSubBreeds.readyState == 4) {
            if (xhrSubBreeds.status == 200) {
                const subBreedsData = JSON.parse(xhrSubBreeds.responseText);
                displaySubBreedsList(subBreedsData.message);
            } else {
                console.error("Error fetching sub-breeds:", xhrSubBreeds.statusText);
            }
        }
    };

    xhrSubBreeds.open("GET", subBreedsUrl);
    xhrSubBreeds.send();
}

function displaySubBreedsList(subBreeds) {
    const breedInfo = document.querySelector("#breedInfo");

    breedInfo.innerHTML = "";

    if (subBreeds && subBreeds.length > 0) {
        breedInfo.innerHTML += "<p><i>Sub-Breeds:</i></p>";
        const subBreedsList = document.createElement("ul");
        subBreeds.forEach(subBreed => {
            const listItem = document.createElement("li");
            listItem.textContent = subBreed;
            subBreedsList.appendChild(listItem);
        });
        breedInfo.appendChild(subBreedsList);
    }
}

function clearLocalStorage() {
    localStorage.clear();
    alert("Local storage cleared!");
}

function searchRandomImage() {
    const selectedBreed = document.querySelector("#breedDropdown").value;

    if (!selectedBreed) {
        alert("Please select a dog breed");
        return;
    }

    const DOG_API_URL_IMAGES = `https://dog.ceo/api/breed/${selectedBreed}/images/random`;

    let xhrImage = new XMLHttpRequest();
    xhrImage.onreadystatechange = function () {
        if (xhrImage.readyState == 4) {
            if (xhrImage.status == 200) {
                const randomImageData = JSON.parse(xhrImage.responseText);
                displayRandomImage(selectedBreed, randomImageData.message);
            } else {
                console.error("Error fetching random dog image:", xhrImage.statusText);
                document.querySelector("#imageSearchStatus").innerHTML = "<b>Error fetching random dog image</b>";
            }
        }
    };

    xhrImage.open("GET", DOG_API_URL_IMAGES);
    xhrImage.send();
}

function displayRandomImage(selectedBreed, imageUrl) {
    const dogImage = document.querySelector("#dogImage");
    const imageSearchStatus = document.querySelector("#imageSearchStatus");
    const breedInfo = document.querySelector("#breedInfo");

    const recentImages = JSON.parse(localStorage.getItem("recentImages")) || [];

    if (!recentImages.includes(imageUrl)) {
        dogImage.src = imageUrl;

        recentImages.push(imageUrl);

        if (recentImages.length > 5) {
            recentImages.shift();
        }

        localStorage.setItem("recentImages", JSON.stringify(recentImages));

        let breedInfoContent = `<b>Breed Info:</b><p><i>Name: ${selectedBreed}</i></p>`;

        const subBreedsUrl = `https://dog.ceo/api/breed/${selectedBreed}/list`;

        let xhrSubBreeds = new XMLHttpRequest();
        xhrSubBreeds.onreadystatechange = function () {
            if (xhrSubBreeds.readyState == 4) {
                if (xhrSubBreeds.status == 200) {
                    const subBreedsData = JSON.parse(xhrSubBreeds.responseText);

                    // Check if there are sub-breeds
                    if (subBreedsData.message && subBreedsData.message.length > 0) {
                        breedInfoContent += "<p><i>Sub-Breeds:</i></p><ul>";
                        subBreedsData.message.forEach(subBreed => {
                            const buttonId = `${selectedBreed}_${subBreed}_button`;
                            breedInfoContent += `<li><button id="${buttonId}" onclick="searchImagesForSubBreed('${selectedBreed}', '${subBreed}')">${subBreed}</button></li>`;
                        });
                        breedInfoContent += "</ul>";
                    }

                    breedInfo.innerHTML = breedInfoContent;

                    imageSearchStatus.innerHTML = `<b>Success!</b><p><i>Random image of the ${selectedBreed} breed</i></p>`;
                } else {
                    console.error("Error fetching sub-breeds:", xhrSubBreeds.statusText);
                }
            }
        };

        xhrSubBreeds.open("GET", subBreedsUrl);
        xhrSubBreeds.send();
    } else {
        imageSearchStatus.innerHTML = `<b>Image already displayed for the ${selectedBreed} breed</b>`;
    }
}

function getDogBreeds() {
    const DOG_API_URL = "https://dog.ceo/api/breeds/list/all";

    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                const data = JSON.parse(xhr.responseText);
                displayDogBreeds(data.message);
            } else {
                console.error("Error fetching dog breeds:", xhr.statusText);
                document.querySelector("#dogBreedsStatus").innerHTML = "<b>Error fetching dog breeds</b>";
            }
        }
    };

    xhr.open("GET", DOG_API_URL);
    xhr.send();
}

function displayDogBreeds(dogBreeds) {
    const breedDropdown = document.querySelector("#breedDropdown");

    // Add each dog breed to the dropdown
    for (const breed in dogBreeds) {
        const option = document.createElement("option");
        option.value = breed;
        option.text = breed[0].toUpperCase() + breed.slice(1);
        breedDropdown.add(option);
    }

    document.querySelector("#dogBreedsStatus").innerHTML = "<b>Success!</b><p><i>Here are dog breeds</i></p>";
}

function searchImagesForSubBreed(selectedBreed, subBreed) {
    const subBreedImageUrl = `https://dog.ceo/api/breed/${selectedBreed}/${subBreed}/images/random`;

    let xhrSubBreedImage = new XMLHttpRequest();
    xhrSubBreedImage.onreadystatechange = function () {
        if (xhrSubBreedImage.readyState == 4) {
            if (xhrSubBreedImage.status == 200) {
                const subBreedImageData = JSON.parse(xhrSubBreedImage.responseText);
                displayRandomImage(`${selectedBreed} - ${subBreed}`, subBreedImageData.message);
            } else {
                console.error("Error fetching random dog image:", xhrSubBreedImage.statusText);
                document.querySelector("#imageSearchStatus").innerHTML = "<b>Error fetching random dog image</b>";
            }
        }
    };

    xhrSubBreedImage.open("GET", subBreedImageUrl);
    xhrSubBreedImage.send();
}