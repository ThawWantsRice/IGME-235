// Selecting the content div and setting up event listeners
const contentsDiv = document.querySelector("#content");

document.querySelector("#breedDropdown").addEventListener("change", searchButtonClicked);
document.querySelector("#searchButton").addEventListener("click", searchRandomImage);
document.querySelector("#breedDropdown").addEventListener("change", updateSubBreedDropdown);
document.querySelector("#displaySavedButton").addEventListener("click", displaySavedImages);

// Array to store saved images
let savedImages = [];

// Initializing the dog breeds when the DOM content is loaded
document.addEventListener("DOMContentLoaded", () => {
    getDogBreeds();
});

// Function to refresh the page
function refreshPage() {
    location.reload();
}

// Function to handle breed selection
function searchButtonClicked() {
    const selectedBreed = document.querySelector("#breedDropdown").value;
    const subBreedSelect = document.querySelector("#subBreedDropdown").value;

    highlightSelectedBreed(selectedBreed);
    highlightSelectedBreed(subBreedSelect);
}

// Function to highlight the selected breed in the dropdown
function highlightSelectedBreed(selectedBreed) {
    const breedDropdown = document.querySelector("#breedDropdown");
    const subBreedDropdown = document.querySelector("#subBreedDropdown");

    // Resetting font weight for all options
    for (const option of breedDropdown.options) {
        option.style.fontWeight = "normal";
    }

    for (const option of subBreedDropdown.options) {
        option.style.fontWeight = "normal";
    }

    // Setting bold font weight for the selected options
    const selectedOption = breedDropdown.querySelector(`[value="${selectedBreed}"]`);
    if (selectedOption) {
        selectedOption.style.fontWeight = "bold";
    }

    const selectedSubBreedOption = subBreedDropdown.querySelector(`[value="${selectedBreed}"]`);
    if (selectedSubBreedOption) {
        selectedSubBreedOption.style.fontWeight = "bold";
    }
}

// Function to update the sub-breed dropdown based on the selected breed
function updateSubBreedDropdown() {
    const selectedBreed = document.querySelector("#breedDropdown").value;

    // Placed for consistency even though they can't pick a null
    if (!selectedBreed) {
        return;
    }

    const subBreedsUrl = `https://dog.ceo/api/breed/${selectedBreed}/list`;

    let xhrSubBreeds = new XMLHttpRequest();
    xhrSubBreeds.onreadystatechange = function () {
        if (xhrSubBreeds.readyState == 4) {
            if (xhrSubBreeds.status == 200) {
                const subBreedsData = JSON.parse(xhrSubBreeds.responseText);
                updateDropdownOptions(subBreedsData.message);
            } else {
                // console.error("Error fetching sub-breeds:", xhrSubBreeds.statusText);
            }
        }
    };

    xhrSubBreeds.open("GET", subBreedsUrl);
    xhrSubBreeds.send();
}

// Function to update the sub-breed dropdown options
function updateDropdownOptions(subBreeds) {
    const subBreedDropdown = document.querySelector("#subBreedDropdown");
    subBreedDropdown.innerHTML = ""; // Clear existing options

    if (subBreeds && subBreeds.length > 0) {
        // Create a default option for no sub-breed selected
        const defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.text = "Select Sub-Breed";
        subBreedDropdown.add(defaultOption);

        // Add sub-breeds to the dropdown
        subBreeds.forEach(subBreed => {
            const option = document.createElement("option");
            option.value = subBreed;
            option.text = subBreed;
            subBreedDropdown.add(option);
        });

        // Show the sub-breed dropdown
        subBreedDropdown.style.display = "inline-block";

        // Check if a sub-breed is selected
        const selectedSubBreed = subBreedDropdown.value;
        if (selectedSubBreed) {
            // Call the function to search images for the selected sub-breed
            searchImagesForSubBreed(selectedBreed, selectedSubBreed);
        }
    } else {
        // Hide the sub-breed dropdown if no sub-breeds available
        subBreedDropdown.style.display = "none";
    }
}

// Function to search for a random dog image
function searchRandomImage() {
    const selectedBreed = document.querySelector("#breedDropdown").value;
    const selectedSubBreed = document.querySelector("#subBreedDropdown").value;

    // Placed for consistency even though they can't pick a null
    if (!selectedBreed) {
        alert("Please select a dog breed");
        return;
    }

    // Check if there is a selected sub-breed
    if (selectedSubBreed) {
        // API URL for random dog image of the selected sub-breed
        const DOG_API_URL_IMAGES = `https://dog.ceo/api/breed/${selectedBreed}/${selectedSubBreed}/images/random`;

        try {
            // Fetching the random dog image and displaying it
            const json = httpGet(DOG_API_URL_IMAGES);
            const randomImageData = JSON.parse(json);
            displayRandomImage(`${selectedBreed} - ${selectedSubBreed}`, randomImageData.message);
        } catch (error) {
            // console.error("Error fetching random dog image:", error.message);
            document.querySelector("#imageSearchStatus").innerHTML = `<b>${error.message}</b>`;
        }
    } else {
        // API URL for random dog image of the selected breed
        const DOG_API_URL_IMAGES = `https://dog.ceo/api/breed/${selectedBreed}/images/random`;

        try {
            // Fetching the random dog image and displaying it
            const json = httpGet(DOG_API_URL_IMAGES);
            const randomImageData = JSON.parse(json);
            displayRandomImage(selectedBreed, randomImageData.message);
        } catch (error) {
            // console.error("Error fetching random dog image:", error.message);
            document.querySelector("#imageSearchStatus").innerHTML = `<b>${error.message}</b>`;
        }
    }
}

// Function to display a random dog image
function displayRandomImage(selectedBreed, imageUrl) {
    let imageSearchStatus = document.querySelector("#imageSearchStatus");
    let formattedBreed = selectedBreed.charAt(0).toUpperCase() + selectedBreed.slice(1);

    if (!imageSearchStatus) {
        imageSearchStatus = document.createElement("div");
        imageSearchStatus.id = "imageSearchStatus";
        document.body.appendChild(imageSearchStatus);
    }

    contentsDiv.innerHTML = "";

    const infoDiv = document.createElement("div");
    infoDiv.classList.add("infoArea");

    const title = document.createElement("h2");
    title.classList.add("titleArea");
    title.textContent = formattedBreed;

    const image = document.createElement("img");
    image.classList.add("imageArea");
    image.src = imageUrl;
    image.alt = `Image of a ${formattedBreed}`;

    let saveButton = document.createElement("button");
    saveButton.classList.add("saveButton");
    saveButton.id = "saveButton";
    saveButton.textContent = "Save Image";

    saveButton.addEventListener("click", function () {
        if (checkSaved(imageUrl)) {
            alert("Image already saved!");
            return;
        }

        savedImages.push(imageUrl);
        localStorage.setItem("savedImages", JSON.stringify(savedImages));

        alert("Image saved!");
    });

    contentsDiv.appendChild(infoDiv);
    infoDiv.appendChild(title);
    infoDiv.appendChild(image);
    infoDiv.appendChild(saveButton);
}

// Function to check if an image is saved
function checkSaved(imageUrl) {
    const savedImages = JSON.parse(localStorage.getItem("savedImages")) || [];
    return savedImages.includes(imageUrl);
}

// Function to display saved images
function displaySavedImages() {
    let savedImages = JSON.parse(localStorage.getItem("savedImages")) || [];

    if (!Array.isArray(savedImages)) {
        savedImages = [];
    }

    if (savedImages.length === 0) {
        alert("No saved images to display.");
        return;
    }

    // Creating a div to display saved images
    const savedImagesDiv = document.createElement("div");
    savedImagesDiv.classList.add("savedImageArea");

    const title = document.createElement("h2");
    title.textContent = "Saved Images";

    savedImagesDiv.appendChild(title);

    // Iterating through saved images and creating image elements with delete buttons
    savedImages.forEach((imageUrl) => {
        const savedImage = document.createElement("img");
        savedImage.classList.add("savedImage");
        savedImage.src = imageUrl;
        savedImage.alt = "Saved Dog Image";

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete Image";
        deleteButton.classList.add("deleteButton");
        deleteButton.addEventListener("click", function () {
            deleteSavedImage(imageUrl);
            savedImage.remove();
            deleteButton.remove();
        });

        savedImagesDiv.appendChild(savedImage);
        savedImagesDiv.appendChild(deleteButton);
    });

    contentsDiv.innerHTML = "";
    contentsDiv.appendChild(savedImagesDiv);
}

// Function to delete a saved image
function deleteSavedImage(imageUrl) {
    savedImages = savedImages.filter(savedImage => savedImage !== imageUrl);
    localStorage.setItem("savedImages", JSON.stringify(savedImages));
    displaySavedImages();
}

// Function to fetch dog breeds from the API
function getDogBreeds() {
    const DOG_API_URL = "https://dog.ceo/api/breeds/list/all";

    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) {
            return;
        }

        if (xhr.status !== 200) {
            // console.error("Error fetching dog breeds:", xhr.statusText);
            document.querySelector("#dogBreedsStatus").innerHTML = "<b>Error fetching dog breeds</b>";
            return;
        }

        const data = JSON.parse(xhr.responseText);
        displayDogBreeds(data.message);
    };

    xhr.open("GET", DOG_API_URL);
    xhr.send();
}

// Function to display dog breeds in the dropdown
function displayDogBreeds(dogBreeds) {
    const breedDropdown = document.querySelector("#breedDropdown");

    // Add each dog breed to the dropdown
    for (const breed in dogBreeds) {
        const option = document.createElement("option");
        option.value = breed;
        option.text = breed[0].toUpperCase() + breed.slice(1);
        breedDropdown.add(option);
    }
}

// FUnction to search for subbreeds
function searchImagesForSubBreed(selectedBreed, subBreed) {
    const subBreedImageUrl = `https://dog.ceo/api/breed/${selectedBreed}/${subBreed}/images/random`;

    let xhrSubBreedImage = new XMLHttpRequest();
    xhrSubBreedImage.onreadystatechange = function () {
        if (xhrSubBreedImage.readyState == 4) {
            if (xhrSubBreedImage.status == 200) {
                const subBreedImageData = JSON.parse(xhrSubBreedImage.responseText);
                displayRandomImage(`${selectedBreed} - ${subBreed}`, subBreedImageData.message);
            } else {
                // console.error("Error fetching random dog image:", xhrSubBreedImage.statusText);
                document.querySelector("#imageSearchStatus").innerHTML = "<b>Error fetching random dog image</b>";
            }
        }
    };

    xhrSubBreedImage.open("GET", subBreedImageUrl);
    xhrSubBreedImage.send();
}

// Function to perform a synchronous GET request
function httpGet(theUrl) {
    const xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", theUrl, false);
    xmlHttp.send(null);
    return xmlHttp.responseText;
}
