window.onload = ()=>{
    initBoard();
    initAboveCards();
    document.body.addEventListener('click', () => {
        playBackgroundMusic();
        
        // Remove the click event listener to avoid playing the music multiple times
        document.body.removeEventListener('click', playBackgroundMusic);
    });
}

const numCards = 12;

const numColumns = 6; // Number of columns in each row
const numRows = 2;    // Number of rows
 
 // 6 pairs of cards in the initial deck
 let deck = [
    'cardR01C01', 'cardR01C01',
    'cardR01C04', 'cardR01C04',
    'cardR01C03', 'cardR01C03',
    'cardR01C02', 'cardR01C02',
    'cardR01C06', 'cardR01C06',
    'cardR01C05', 'cardR01C05',
    // 'cardR01C07', 'cardR01C07',
    // 'cardR01C08', 'cardR01C08',
    // 'cardR01C09', 'cardR01C09',
    // 'cardR01C010', 'cardR01C010',
 ];
 

 function initBoard(){
   // here we pass array.sort() a *compare function* that returns a random number
   // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
   deck.sort(()=>{ return 0.5 - Math.random() }); // randomize the deck

   // in this loop we clone the existing card on the page 11 times
   // https://developer.mozilla.org/en-US/docs/Web/API/Node/cloneNode
   for (let i = 0; i < numCards - 1; i++) {
    let newCard = document.querySelector("#cards .card").cloneNode(true);
    document.querySelector("#cards").appendChild(newCard);
}

   /* Now position the cards on the table, and assign a face: */
   let cards = document.querySelectorAll("#cards > .card");
   let index = 0; // we need this for positioning
    
   // loop through all of the card elements and assign a face to each card
   for (let row = 0; row < numRows; row++) {
    for (let col = 0; col < numColumns; col++) {
        let element = cards[index];

        let x = (element.offsetWidth + 20) * col;
            let y = (element.offsetHeight + 20) * row;
            element.style.transform = "translateX(" + x + "px) translateY(" + y + "px)";

            // get a pattern from the shuffled deck
            let pattern = deck.pop();

            // visually apply the pattern on the card's back side.
            // we do this by adding a class through the .classList property
            // https://developer.mozilla.org/en-US/docs/Web/API/Element/classList
            element.querySelector(".back").classList.add(pattern);

            // embed the pattern data into the DOM element.
            // this is an example of HTML5 Custom Data attributes
            // http://html5doctor.com/html5-custom-data-attributes/
            element.setAttribute("data-pattern",pattern);

            // listen for the click event on each card <div> element.
            element.onclick = cardClicked;
            index ++;
        }
    }
 }

   function cardClicked() {
       // we do nothing if there are already two cards flipped.
       console.log("Card clicked!");
       if (document.querySelectorAll(".card-flipped").length > 1) return;
       
       // inside of an event handling function, 'this' is the element that called the function
       this.classList.add("card-flipped");

       // check the pattern of both flipped card 0.7s later.    
       if (document.querySelectorAll(".card-flipped").length == 2) {
           // setTimeout() is used to schedule the execution a piece of code *once*
           // https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/setTimeout
           setTimeout(checkPattern, 700);
       }
   }

//  function checkPattern() {
//     if (isSamePattern()) {
//     // here we are using array.forEach(), rather than for...of, for no particular reason :-)
//      document.querySelectorAll(".card-flipped").forEach((element)=>{
//          element.classList.remove("card-flipped");
//          element.classList.add("card-removed");
//         element.addEventListener("transitionend",removeMatchedCards);
//      });
//    } else {
//    // I prefer array.forEach() over for...of when I can write it as a "one-liner"
//      document.querySelectorAll(".card-flipped").forEach((element)=>{element.classList.remove("card-flipped")});
//    }
//  }

 function isSamePattern() {
   let cards = document.querySelectorAll(".card-flipped");
   // the dataset object holds the .data-pattern property we created for each card in initBoard()
   let pattern1 = cards[0].dataset.pattern;
   let pattern2 = cards[1].dataset.pattern;
   return pattern1 == pattern2;
 }

 function removeMatchedCards() {
    // Remove the class that marks the cards as removed
    document.querySelectorAll(".card-removed").forEach((element) => {
        element.classList.remove("card-removed");
    });
}


const backgroundMusic = new Audio("audio/BGM.wav");

function playBackgroundMusic() {
    backgroundMusic.loop = true; // Set to true for continuous looping
    backgroundMusic.volume = 0.5; // Adjust the volume (0.0 to 1.0)
    backgroundMusic.play();
}

const muteButton = document.createElement('button');
muteButton.textContent = 'Toggle Music';
document.body.appendChild(muteButton);

muteButton.addEventListener('click', () => {
    backgroundMusic.muted = !backgroundMusic.muted;
});

const volumeSlider = document.createElement('input');
volumeSlider.type = 'range';
volumeSlider.min = 0;
volumeSlider.max = 1;
volumeSlider.step = 0.1;
volumeSlider.value = backgroundMusic.volume; // Set initial value

// Append the volume slider to the body
document.body.appendChild(volumeSlider);

// Add an event listener to update the volume when the slider is moved
volumeSlider.addEventListener('input', () => {
    backgroundMusic.volume = parseFloat(volumeSlider.value);
});


const numAboveColumns = 2; // Adjust as needed
const numAboveRows = 1;    // Adjust as needed
const numAboveCards = numAboveColumns * numAboveRows;

let aboveDeck = [...Array(numAboveCards).keys()].map(() => getRandomPattern());

function initAboveCards() {
    let aboveCardsSection = document.getElementById("aboveCards");

    for (let i = 0; i < numAboveCards; i++) {
        let aboveCard = document.querySelector("#cards .card").cloneNode(true);

        aboveCard.querySelector(".front").classList = "face front";
        aboveCard.classList.add("card-flipped", "above-card");

        aboveCardsSection.appendChild(aboveCard);
    }

    let aboveCards = document.querySelectorAll("#aboveCards > .card");
    let index = 0;

    for (let row = 0; row < numAboveRows; row++) {
        for (let col = 0; col < numAboveColumns; col++) {
            let element = aboveCards[index];

            let x = (element.offsetWidth + 10) * col;
            let y = (element.offsetHeight + 10) * row;
            element.style.transform = "translateX(" + x + "px) translateY(" + y + "px)";

            let pattern = aboveDeck.pop();
            element.querySelector(".front").classList.add(pattern);
            element.setAttribute("data-pattern", pattern);

            index++;
        }
    }
}



function getRandomPattern() {
    // Add logic to get a random pattern for above cards
    // You can implement this according to your requirements
    // For example, you can return a random number or a string representing a pattern
    // Ensure that the logic here is suitable for your game
    return 'pattern' + Math.floor(Math.random() * 5 + 1); // Change this as needed
}

function replaceAboveCards() {
    let aboveCardsSection = document.getElementById("aboveCards");
    aboveCardsSection.innerHTML = ''; // Clear the existing cards

    for (let i = 0; i < numAboveCards; i++) {
        let aboveCard = document.querySelector(".card").cloneNode(true);
        aboveCard.querySelector(".front").classList = "face front"; // Set the class directly for the front face
        aboveCard.classList.add("card-flipped"); // Make the card initially flipped

        aboveCardsSection.appendChild(aboveCard);
    }

    // Additional logic for initializing the new set of above cards...
}


// Modify the cardClicked and removeMatchedCards functions accordingly to handle above cards
// ...

function checkPattern() {
    if (isSamePattern()) {
        document.querySelectorAll(".card-flipped").forEach((element) => {
            element.classList.remove("card-flipped");
            element.classList.add("card-removed");
            element.addEventListener("transitionend", removeMatchedCards);
        });

        // Replace the above cards after a short delay
        setTimeout(replaceAboveCards, 700);
    } else {
        document.querySelectorAll(".card-flipped").forEach((element) => {
            element.classList.remove("card-flipped");
        });
        
        // Flip back the above cards if there's a mismatch
        document.querySelectorAll("#aboveSection .card-flipped").forEach((element) => {
            element.classList.remove("card-flipped");
        });
    }
}

